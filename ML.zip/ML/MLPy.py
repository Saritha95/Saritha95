import pandas as pd
import csv
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_diabetes
import numpy as np


#make a dataframe
df = pd.read_csv(r"C://Users//Saritha Devi//Desktop//ML//input//data.csv")
#examine the shape of the data
print(df)
#df.shape()
#get the column names
df.columns
                  
#Drop the column with all missing values (na, NAN, NaN)
#NOTE: This drops the column Unnamed: 32 column
df = df.dropna(axis=1)
#Get a count of the number of 'M' & 'B' cells
df['diagnosis'].value_counts()
#Visualize this count 
sns.countplot(df['diagnosis'],label="Count")
# y includes diagnosis column with M or B values
y = df.diagnosis
# drop the column 'id' as it is does not convey any useful info
# drop diagnosis since we are separating labels and features 
list = ["id","diagnosis"]
# X includes our features
X = df.drop(list,axis = 1)
# get the first ten features
data_dia = y
data = X
data_std = (data — data.mean()) / (data.std()) # standardization
# get the first 10 features
data = pd.concat([y,data_std.iloc[:,0:10]],axis=1)
data = pd.melt(data,id_vars=”diagnosis”,
 var_name=”features”,
 value_name=’value’)
# make a violin plot
plt.figure(figsize=(10,10))
sns.violinplot(x=”features”, y=”value”, hue=”diagnosis”, data=data,split=True, inner=”quart”)
plt.xticks(rotation=90)
