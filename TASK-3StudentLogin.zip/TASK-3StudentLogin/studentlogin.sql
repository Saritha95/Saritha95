-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 28, 2021 at 08:54 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `flask`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` text NOT NULL,
  `studentname` varchar(30) NOT NULL,
  `SEM1` varchar(30) NOT NULL,
  `SEM2` varchar(30) NOT NULL,
  `studentclass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `studentname`, `SEM1`, `SEM2`, `studentclass`) VALUES
('1', 'Abi', '9', '9', 1),
('2', 'BRUCE', '7', '7', 1),
('1', 'Vidyut', '8', '8', 2),
('2', 'Vikrant', '9', '9', 2),
('2', 'abc', '18', '9', 3),
('4', 'john', '19', '18', 4),
('5', 'Sari', '12', '15', 1),
('5', 'Ram', '15', '12', 4),
('6', 'wer', '15', '12', 6),
('2', 'Sari', '10', '9', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
