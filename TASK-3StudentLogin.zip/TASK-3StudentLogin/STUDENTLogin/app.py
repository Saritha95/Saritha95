from flask import Flask, render_template, request, flash, session, url_for, redirect
from flask_mysqldb import MySQL
# from flask_table import table, col

app = Flask(__name__)
app.secret_key = "#gydgvdsfkgdfw4587yt45g"

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flask'

mysql = MySQL(app)
print("success")


@app.route('/')
def home():
    return render_template("home.html")


@app.route('/index',methods=['POST','GET'])
def index():
    return render_template('index.html')


@app.route('/Staff', methods=['POST', 'GET'])
def Staff():
    return render_template('staff1.html')


@app.route('/staff_login')
def staff_login():
    return render_template('staff_page.html')


@app.route('/stafflogin_data', methods=['POST', 'GET'])
def stafflogin_data():
    return render_template('staff.html')


@app.route('/login_data', methods=['POST', 'GET'])
def login_data():
    if request.method == "POST":
        id = request.form.get('id')
        studentname = request.form.get('studentname')
        SEM1 = request.form.get('SEM1')
        SEM2 = request.form.get('SEM2')
        studentclass = request.form.get('studentclass')
        cur = mysql.connection.cursor()
        sql = "INSERT INTO student(id, studentname,SEM1,SEM2, studentclass) VALUES (%s,%s,%s,%s,%s)"
        val = (id, studentname,SEM1, SEM2, studentclass)
        cur.execute(sql, val)
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('index'))


@app.route('/Studententry', methods=['POST', 'GET'])
def studententry():
    return render_template('studententry.html')


@app.route('/Student', methods=['POST', 'GET'])
def student():
    if request.method == "POST":
        name= request.form.get('studentname')
        id = request.form.get('id')
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM student where id = %s and studentname = %s ", (id , name))
        data = cur.fetchall()
        return render_template('Student.html', data=data)


if __name__ == "__main__":
    app.run(debug=True)
